import { Component, Input } from '@angular/core';
import {Card} from './card';
import { CdkDragDrop, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';
@Component({
  selector: 'drag-card-component',
  template: `
  <div class="operationArea orders-drop-down" cdkDropList="cardModel" (cdkDropListDropped)="drop($event)">
    <div fxLayout="row" fxLayoutAlign="space-around center" class="drag_dropCard" *ngFor="let card of cardModel" cdkDragBoundary=".operationArea" cdkDrag>
     <span> {{card.name}}</span>     
    </div>
</div>`,
  styles: [`h1 { font-family: Lato; }`]
})
export class HelloComponent  {
   @Input() cardModel: Array<Card>;


   ngOnInit():void{
       console.log(this.cardModel);

    }
     drop(event: CdkDragDrop<string[]>) {
        if (event.previousContainer === event.container) {
       console.log(this.cardModel);
        console.log(this.cardModel[event.previousIndex].orderBy);
       console.log(event.previousIndex); // neeed to change this by 
       console.log(event.currentIndex);
       moveItemInArray(this.cardModel, event.previousIndex, event.currentIndex);
      } else {
        transferArrayItem(event.previousContainer.data,
          event.container.data,
          event.previousIndex,
          event.currentIndex);
      }
      }
}



