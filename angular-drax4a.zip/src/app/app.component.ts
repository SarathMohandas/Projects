import { Component } from '@angular/core';
import {Card} from './card';

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: [ './app.component.css' ]
})
export class AppComponent  {
  name = 'Angular';
   operationModel: Card[];
    // actionModel: Card[];
    // componentModel: Card[];
    // traceModel: Card[];



    ngOnInit(): void {
   
    this.operationModel =[
        {id: 1, name: 'Operation1', icon: 'settings', hasSub : false, parentId:0, orderBy:1},
        {id: 2, name: 'Operation2', icon: 'settings', hasSub : false, parentId:0 , orderBy:2},
        {id: 3, name: 'Operation3', icon: 'settings', hasSub : false, parentId:0 , orderBy:3},
        {id: 4, name: 'Operation4', icon: 'settings', hasSub : false, parentId:0 , orderBy:5},
    ];
    // this.actionModel =[
    //     {id: 1, name: 'Action1', icon: 'build', hasSub : false, parentId:0},
    //     {id: 2, name: 'Action2', icon: 'build', hasSub : false, parentId:0},
    //     {id: 3, name: 'Action3', icon: 'build', hasSub : false, parentId:0},
    //     {id: 4, name: 'Action4', icon: 'build', hasSub : false, parentId:0},
    // ];
    // this.componentModel =[
    //     {id: 1, name: 'component1', icon: 'settings', hasSub : false, parentId:0},
    //     {id: 2, name: 'component2', icon: 'settings', hasSub : false, parentId:0},
    //     {id: 3, name: 'component3', icon: 'settings', hasSub : false, parentId:0},
    //     {id: 4, name: 'component4', icon: 'settings', hasSub : false, parentId:0},
    // ];
    // this.traceModel =[
    //     {id: 1, name: 'trace1', icon: 'settings', hasSub : false, parentId:0},
    //     {id: 2, name: 'trace2', icon: 'settings', hasSub : false, parentId:0},
    //     {id: 3, name: 'trace3', icon: 'settings', hasSub : false, parentId:0},
    //     {id: 4, name: 'trace4', icon: 'settings', hasSub : false, parentId:0},
    // ];
}
onApply() : void {
  console.log(this.operationModel);
  

}
}
