export interface Card {
    id: number;
    name: string;
    icon: string;
    hasSub: boolean;
    parentId: number;
    orderBy?: number;
}